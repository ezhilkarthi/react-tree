import React from 'react';
import './App.css';

import FileExplore from './FileExplore/FileExplore';

function App() {
  return (
    <div className="">
     <FileExplore />
    </div>
  );
}

export default App;
